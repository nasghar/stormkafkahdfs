package com.hortonworks.streaming.impl.topologies;

import com.hortonworks.streaming.impl.kafka.CddsMessageEventScheme;
import org.apache.log4j.Logger;
import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.format.DefaultFileNameFormat;
import org.apache.storm.hdfs.bolt.format.DelimitedRecordFormat;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.sync.CountSyncPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;

import storm.kafka.BrokerHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.ZkHosts;
import backtype.storm.Config;
import backtype.storm.StormSubmitter;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.topology.TopologyBuilder;

import com.hortonworks.streaming.impl.bolts.hdfs.FileTimeRotationPolicy;
import com.hortonworks.streaming.impl.bolts.hive.HiveTablePartitionAction;

public class CddsEventProcessorKafkaTopology extends BaseCddsEventTopology {
	
	private static final Logger LOG = Logger.getLogger(CddsEventProcessorKafkaTopology.class);
	
	
	public CddsEventProcessorKafkaTopology(String configFileLocation) throws Exception {
		
		super(configFileLocation);			
	}

	private void buildAndSubmit() throws Exception {
		TopologyBuilder builder = new TopologyBuilder();
		
		/* Set up Kafka Spout to ingest from */
		configureKafkaSpout(builder);

		/* Set up HDFSBOlt to send every cdds event to HDFS */
		configureHDFSBolt(builder);
		

		
		/* This conf is for Storm and it needs be configured with things like the following:
		 * 	Zookeeper server, nimbus server, ports, etc... All of this configuration will be picked up
		 * in the ~/.storm/storm.yaml file that will be located on each storm node.
		 */
		Config conf = new Config();
		conf.setDebug(true);	
		/* Set the number of workers that will be spun up for this topology. 
		 * Each worker represents a JVM where executor thread will be spawned from */
		Integer topologyWorkers = Integer.valueOf(topologyConfig.getProperty("storm.cdds.topology.workers"));
		conf.put(Config.TOPOLOGY_WORKERS, topologyWorkers);
		
		try {
			StormSubmitter.submitTopology("cdds-event-processor", conf, builder.createTopology());
		} catch (Exception e) {
			LOG.error("Error submiting Topology", e);
		}
			
	}



	public void configureHDFSBolt(TopologyBuilder builder) {
		// Use pipe as record boundary
		
		String rootPath = topologyConfig.getProperty("hdfs.path");
		String prefix = topologyConfig.getProperty("hdfs.file.prefix");
		String fsUrl = topologyConfig.getProperty("hdfs.url");
		String sourceMetastoreUrl = topologyConfig.getProperty("hive.metastore.url");
		String hiveStagingTableName = topologyConfig.getProperty("hive.staging.table.name");
		String databaseName = topologyConfig.getProperty("hive.database.name");
		Float rotationTimeInMinutes = Float.valueOf(topologyConfig.getProperty("hdfs.file.rotation.time.minutes"));
		
		RecordFormat format = new DelimitedRecordFormat().withFieldDelimiter(",");

		//Synchronize data buffer with the filesystem every 1000 tuples
		SyncPolicy syncPolicy = new CountSyncPolicy(1000);

		// Rotate data files when they reach five MB
		//FileRotationPolicy rotationPolicy = new FileSizeRotationPolicy(5.0f, Units.MB);
		
		//Rotate every X minutes
		FileTimeRotationPolicy rotationPolicy = new FileTimeRotationPolicy(rotationTimeInMinutes, FileTimeRotationPolicy.Units.MINUTES);
		
		//Hive Partition Action
		HiveTablePartitionAction hivePartitionAction = new HiveTablePartitionAction(sourceMetastoreUrl, hiveStagingTableName, databaseName, fsUrl);
		
		//MoveFileAction moveFileAction = new MoveFileAction().toDestination(rootPath + "/working");


		
		FileNameFormat fileNameFormat = new DefaultFileNameFormat()
				.withPath(rootPath + "/staging")
				.withPrefix(prefix);

		// Instantiate the HdfsBolt
		HdfsBolt hdfsBolt = new HdfsBolt()
				 .withFsUrl(fsUrl)
		         .withFileNameFormat(fileNameFormat)
		         .withRecordFormat(format)
		         .withRotationPolicy(rotationPolicy)
		         .withSyncPolicy(syncPolicy)
		         .addRotationAction(hivePartitionAction);
		
		int hdfsBoltCount = Integer.valueOf(topologyConfig.getProperty("hdfsbolt.thread.count"));
		builder.setBolt("hdfs_bolt", hdfsBolt, hdfsBoltCount).shuffleGrouping("kafkaSpout");
	}

	public int configureKafkaSpout(TopologyBuilder builder) {
		KafkaSpout kafkaSpout = constructKafkaSpout();
		
		int spoutCount = Integer.valueOf(topologyConfig.getProperty("spout.thread.count"));
		int boltCount = Integer.valueOf(topologyConfig.getProperty("bolt.thread.count"));
		
		builder.setSpout("kafkaSpout", kafkaSpout, spoutCount);
		return boltCount;
	}



	/**
	 * Construct the KafkaSpout which comes from the jar storm-kafka-0.8-plus
	 * @return
	 */
	private KafkaSpout constructKafkaSpout() {
		KafkaSpout kafkaSpout = new KafkaSpout(constructKafkaSpoutConf());
		return kafkaSpout;
	}

	/**
	 * Construct 
	 * @return
	 */
	private SpoutConfig constructKafkaSpoutConf() {
		BrokerHosts hosts = new ZkHosts(topologyConfig.getProperty("kafka.zookeeper.host.port"));
		String topic = topologyConfig.getProperty("kafka.topic");
		String zkRoot = topologyConfig.getProperty("kafka.zkRoot");
		String consumerGroupId = topologyConfig.getProperty("kafka.consumer.group.id");
		
		SpoutConfig spoutConfig = new SpoutConfig(hosts, topic, zkRoot, consumerGroupId);
		
		/* Custom CddsScheme that will take Kafka message of single cddsEvent  */
		spoutConfig.scheme = new SchemeAsMultiScheme(new CddsMessageEventScheme());
		
		return spoutConfig;
	}
	
	public static void main(String[] args) throws Exception {
		String configFileLocation = args[0];
		CddsEventProcessorKafkaTopology cddsTopology = new CddsEventProcessorKafkaTopology(configFileLocation);
		cddsTopology.buildAndSubmit();
		
	}	

}



