package com.hortonworks.streaming.impl.kafka;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import backtype.storm.spout.Scheme;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

public class CddsMessageEventScheme implements Scheme{

	private static final long serialVersionUID = -2990121166902741545L;

	private static final Logger LOG = Logger.getLogger(CddsMessageEventScheme.class);
	
	@Override
	public List<Object> deserialize(byte[] bytes) {
		try {
			String cddsEvent = new String(bytes, "UTF-8");
            LOG.info("Raw Message is ["+cddsEvent+"]");
			String[] pieces = cddsEvent.split("\\|");

            Timestamp eventTime = Timestamp.valueOf(pieces[0]);
            String id =pieces[1];
            String status =pieces[2];
            String sourceApplication = pieces[3];
            String sourceAddress = pieces[4];
            String source = pieces[5];
            String destination= pieces[6];
            String payload = pieces[7];
            String error = pieces[8];

			LOG.info("Creating a CDDS Message Scheme with id["+id + "], Event Time["+eventTime+"], source["+source+"], sourceApplication["+ sourceApplication +"], sourceAddress["+sourceAddress + "], and destination["+destination +"]");
			return new Values(id, eventTime,status, sourceApplication,sourceAddress, source, destination, error, payload);
			
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
		
	}

	@Override
	public Fields getOutputFields() {
		return new Fields("id", "eventTime", "status", "sourceApplication","sourceAddress","source","destination", "error", "payload");
		
	}
	


}