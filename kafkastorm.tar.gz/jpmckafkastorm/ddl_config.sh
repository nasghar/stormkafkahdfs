#!/bin/bash
echo 'Creating Hive tables...'
hive -f cdds_events.ddl
runuser -l hdfs -c 'hadoop fs -chown -R storm /apps/hive/warehouse/cdds_events_text_partition'

